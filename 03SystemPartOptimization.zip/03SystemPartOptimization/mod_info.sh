﻿# 安装时显示的模块名称
mod_name="系统优化"
# 安装时显示的模块说明
mod_info_text="修改framework以提升触控灵敏度和滑动跟手度，加入部分安卓Q动画，且修改导航栏高度为23DP需搭配系统美化部分中仿ios横条使用"
# 安装时显示的提示
mod_install_info="是否安装[$mod_name]"

# 按下[音量+]选择的功能提示
mod_yes_text="安装"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_text="[$mod_name]"

# 按下[音量-]选择的功能提示
mod_no_text="不安装"
# 按下[音量-]后加入module.prop的内容
mod_select_no_text=""
mod_require_version=".{0,}"

mod_install_yes(){
	cp -r $MODFILEDIR/* $MODPATH/system/
    return 0
}

mod_install_no()
{
    return 0
}
