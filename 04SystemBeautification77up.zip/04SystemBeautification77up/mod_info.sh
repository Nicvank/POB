﻿# 安装时显示的模块名称
mod_name="系统美化(内测77及以上)"
# 安装时显示的模块说明
mod_info_text="内测77及以上可安装，稳定版切勿安装！修改指纹图标及解锁特效，修改状态栏下拉磁贴数量:竖排下拉3X5,横屏下拉2X6，去除锁屏界面灰色遮罩，修改跑马灯及前置摄像头升起光效，修改小药丸样式为仿ios横条并隐藏返回键，需搭配 系统部分优化 使用"
# 安装时显示的提示
mod_install_info="是否安装[$mod_name]"

# 按下[音量+]选择的功能提示
mod_yes_text="安装"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_text="[$mod_name]"

# 按下[音量-]选择的功能提示
mod_no_text="不安装"
# 按下[音量-]后加入module.prop的内容
mod_select_no_text=""
mod_require_version=".{0,}"

mod_install_yes(){
	cp -r $MODFILEDIR/* $MODPATH/system/
	return 0
}

mod_install_no()
{
    return 0
}
