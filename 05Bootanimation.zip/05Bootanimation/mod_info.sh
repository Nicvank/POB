﻿# 安装时显示的模块名称
mod_name="开机动画"
# 安装时显示的模块说明
mod_info_text="一个简约好看的开机动画"
# 安装时显示的提示
mod_install_info="是否安装[$mod_name]"

# 按下[音量+]选择的功能提示
mod_yes_text="安装"
# 按下[音量+]后加入module.prop的内容
mod_select_yes_text="[$mod_name]"

# 按下[音量-]选择的功能提示
mod_no_text="不安装"
# 按下[音量-]后加入module.prop的内容
mod_select_no_text=""
mod_require_version=".{0,}"

mod_install_yes(){
	cp -r $MODFILEDIR/* $MODPATH/system/
	return 0
}

mod_install_no()
{
    return 0
}
